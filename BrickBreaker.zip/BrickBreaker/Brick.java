import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GradientPaint;

public class Brick extends GameObject {
    boolean destroyed = false;
    Color color = Color.ORANGE;
    // power-up tag: null means no power-up, otherwise a short code
    String powerUpType = null;

    public Brick(int x, int y, int w, int h, Color color) {
        super(x, y, w, h);
        if (color != null) this.color = color;
    }

    public void setPowerUp(String type) {
        this.powerUpType = type;
    }

    @Override
    public void draw(Graphics g) {
        if (!destroyed) {
            Graphics2D g2 = (Graphics2D) g;
            GradientPaint gp = new GradientPaint(x, y, color.brighter(), x + width, y + height, color.darker());
            g2.setPaint(gp);
            g2.fillRect(x, y, width, height);
            g2.setColor(Color.DARK_GRAY);
            g2.drawRect(x, y, width, height);

            // draw small badge for power-up bricks
            if (powerUpType != null) {
                int badgeSize = Math.max(12, Math.min(20, width / 6));
                int bx = x + width - badgeSize - 4;
                int by = y + 4;
                Color badgeColor = Color.MAGENTA;
                String letter = "P";
                if ("PADDLE".equals(powerUpType)) { badgeColor = new Color(0x4C, 0xFF, 0x79); letter = "G"; }
                else if ("SPEED".equals(powerUpType)) { badgeColor = new Color(0xFF, 0xC1, 0x4C); letter = "S"; }
                else if ("CLONE".equals(powerUpType)) { badgeColor = new Color(0x5C, 0xC2, 0xFF); letter = "C"; }
                g2.setColor(new Color(0,0,0,80));
                g2.fillOval(bx+1, by+1, badgeSize, badgeSize);
                g2.setColor(badgeColor);
                g2.fillOval(bx, by, badgeSize, badgeSize);
                g2.setColor(Color.DARK_GRAY);
                g2.drawOval(bx, by, badgeSize, badgeSize);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, Math.max(10, badgeSize-6)));
                FontMetrics fm = g2.getFontMetrics();
                int tx = bx + (badgeSize - fm.stringWidth(letter)) / 2;
                int ty = by + (badgeSize + fm.getAscent()) / 2 - 2;
                g2.drawString(letter, tx, ty);
            }
        }
    }
}
