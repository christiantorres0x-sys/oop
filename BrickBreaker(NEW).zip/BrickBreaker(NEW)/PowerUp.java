import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;

public class PowerUp {
    public enum Type { PADDLE_GROW, PADDLE_SPEED, BALL_CLONE }
    int x, y, size = 14;
    int dy = 3; // falling speed
    Type type;
    boolean active = true;

    public PowerUp(int x, int y, Type type) {
        this.x = x;
        this.y = y;
        this.type = type;
    }

    public void update() {
        y += dy;
    }

    public void draw(Graphics g) {
        Color c = Color.MAGENTA;
        switch (type) {
            case PADDLE_GROW: c = new Color(0x4C, 0xFF, 0x79); break; // green
            case PADDLE_SPEED: c = new Color(0xFF, 0xC1, 0x4C); break; // yellow
            case BALL_CLONE: c = new Color(0x5C, 0xC2, 0xFF); break; // blue
        }
        g.setColor(new Color(0,0,0,60));
        g.fillOval(x+1, y+1, size, size);
        g.setColor(c);
        g.fillOval(x, y, size, size);
        g.setColor(Color.DARK_GRAY);
        g.drawOval(x, y, size, size);
        // icon letter
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, Math.max(10, size-6)));
        String letter = "G";
        if (type == Type.PADDLE_GROW) letter = "G";
        else if (type == Type.PADDLE_SPEED) letter = "S";
        else if (type == Type.BALL_CLONE) letter = "C";
        FontMetrics fm = g.getFontMetrics();
        int tx = x + (size - fm.stringWidth(letter)) / 2;
        int ty = y + (size + fm.getAscent()) / 2 - 2;
        g.drawString(letter, tx, ty);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, size, size);
    }
}
