import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class Ball extends GameObject {
    int dx = 7;
    int dy = -7;
    boolean isClone = false;
    boolean piercing = false;
    boolean fireball = false;

    public Ball(int x, int y, int diameter) {
        super(x, y, diameter, diameter);
    }

    public Ball(int x, int y, int diameter, boolean isClone) {
        super(x, y, diameter, diameter);
        this.isClone = isClone;
    }

    public void move() {
        x += dx;
        y += dy;
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int glowSize = Math.max(width, height) + 18;
        int gx = x + width/2 - glowSize/2;
        int gy = y + height/2 - glowSize/2;
        if (fireball) {
            g2.setColor(new Color(255, 92, 46, 120)); // fiery glow
        } else if (piercing) {
            g2.setColor(new Color(0, 255, 255, 100)); // cyan for piercing
        } else {
            g2.setColor(new Color(255, 140, 140, 90));
        }
        g2.fillOval(gx, gy, glowSize, glowSize);
        g2.setColor(Color.WHITE);
        g2.fillOval(x, y, width, height);
        g2.setColor(new Color(150, 30, 30));
        g2.drawOval(x, y, width, height);
    }
}
